# ====   PATHS ===================

TRAINING_DATA_FILE = "titanic.csv"
PIPELINE_NAME = 'logistic_regression.pkl'


# ======= FEATURE GROUPS =============

TARGET = 

CATEGORICAL_VARS = 

NUMERICAL_VARS = 

CABIN = 