import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
import joblib

from pipeline import titanic_pipe
import config



def run_training():
    """Train the model."""

    # read training data

    # divide train and test

    # fit pipeline

    # save pipeline
    

if __name__ == '__main__':
    run_training()
